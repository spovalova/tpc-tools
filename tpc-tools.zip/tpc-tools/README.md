# tpc-tools

Claude Code plugin marketplace for The Prompting Company.

## Plugins

- **geo-report** — Generate a GEO (answer-engine visibility) baseline report from
  promptingco `prompts` and `cited-sources` exports, in the two-page template.

## Install (for coworkers)

In Claude Code, run:

```
/plugin marketplace add <OWNER>/<REPO>
/plugin install geo-report@tpc-tools
```

Replace `<OWNER>/<REPO>` with this repository (e.g. `promptingco/tpc-tools`).

To get updates later:

```
/plugin marketplace update
```

## Use

Give Claude Code a product's two CSV exports (the `prompts` export and the
`cited-sources` export) and ask for a GEO report. Before the citation mix is
trusted, edit the `OWNED` / `COMPETITOR` domain lists at the top of
`plugins/geo-report/skills/geo-report/analyze.py` for that client.
